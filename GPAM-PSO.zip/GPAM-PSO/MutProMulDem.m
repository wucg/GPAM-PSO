Function [MutNum_num, MutDe_num] = MutProMulDem (x, SelMuRat, N, D, NumOfMut, DemOfMut, interNum)

% Selecting the Particles and Dimensions to Varie

% Choose the most aggregated dimension and the most aggregated particles

%% Constructing Matrix D*N, clust Matrix of Particle Aggregation Degree

% --------------------------------------------------------------------------------------------------------------------------------------------------------------------

X = x;

DemRange = zeros (1, D);

ClustRange = zeros (1, D);

For I = 1:D

DemRange (i) = max (X (:, i) - min (X (:, i));

ClustRange (i) = SelMuRat * DemRange (i);

End

% The particle label corresponding to each element of clustMatrix

ClustMatrix = zeros (D, N);

ParMark = zeros (D, N);

A = cell (D, N);

For DEM = 1:D

% Arrangement of all particles in each dimension in ascending order of distance

ProDem = X (:, dem);

[ProDem, Index] = sort (ProDem);

% particle labeling matrix after rearrangement

ParMark (dem,:) = Index';

ProDemMar = Index';

For num = 1:N

BRR = find (ProDem<=ProDem(num)+clustRange(dem));

ClustMatrix (dem, num) = length (brr) - num + 1;

A {dem, num} = ProDemMar (num: length (brr));

End

End



B = zeros (1, D);% How many particles are aggregated in the largest heap in each dimension

Bmark = cell (1, D);% maximum heap corresponds to the number of particles

For DEM = 1:D

B (dem) = max (clust Matrix (dem,:);

Bmark {dem} = find (clustMatrix (dem,:) == Max (clustMatrix (dem,:));

End

% if interNum > 50 & & interNum < 60

% save (['mutaResult / Penalized1 Distribution Matrix A result / Num2str (interNum)'Generation Distribution Matrix A result. mat'],'B');

% end

% B

%% The Dimension of Variation in Wheel Selection

BMar = 1:D;

For Mutdem = 1: NumOfMut

B = B/sum (B);

SelRat = cumsum (B);

% DemOfMut - ------------------------------------------------------------------------------------------------------------------------------------------------------

SelRat = 0 SelRat;

A = rand;

For I = 1: (length (SelRat) - 1)

If a > SelRat (i) & a <= SelRat (i+1)

Demm = i;

Break;

End

End

MutDem_num (Mutdem) = BMar (Demm);

B(i) = 0;

BMar (i) = 0;

B = nonzeros (B)';

BMar = nonzeros (BMar)';

End

% Select the dimension where the densest heap appears, that is, the maximum value in B

% DemOfMut = find (B = max (B));

% Select the corresponding particle

For DEM = 1: NumOfMut

MutNum_num (dem) = A {MutDem_num (dem), Bmark {MutDem_num (dem)} (1)} (1);

End



% Find the biggest dimension of a particle

For Munumm = 1:NumOfMut

% Dimensions for each variant particle

% Find the D% position of the particle in ParMark and find the aggregation number of the particle in this dimension.

For de = 1:D

MuParMarPosit (de) = find (ParMark (de,:) == MutNum_num (Munumm));

MutParClustNum (de) = clustMatrix (de, MuParMarPosit (de));

End

% Select the front DemOfMut with the largest aggregation number

% Stored in MuteDe_num

[BBBBBB, index] = sort (MutParClustNum);

Index = index';

MutDe_num (Munumm,:) = index (D-DemOfMut+1:D);

MutDe_num (Munumm,:) = fliplr (MutDe_num (Munumm,:));

End

End