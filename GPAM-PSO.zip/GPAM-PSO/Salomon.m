function F = Salomon(x,demantion,roted,M)
% Salomon  boundary=100
if roted==1
    x = x*M';
end

total2 = 0;
for i = 1:demantion
    total2 = total2+x(i)^2; 
end
F = 1-cos(2*pi*sqrt(total2))+0.1*(sqrt(total2));