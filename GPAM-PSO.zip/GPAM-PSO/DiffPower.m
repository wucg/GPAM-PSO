function F = DiffPower(x,demantion,roted,M)


total = 0;
for i = 1:demantion
    a = 10^((i-1)/(demantion-1));
    total = total+(abs(x(i)))^(2+a);
end
F = total;