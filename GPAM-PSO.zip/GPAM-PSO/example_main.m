function mainPsoLHS
M=5000;
demantion = 30;
accuracy = 10^(-5);
c3 = 0.4;
w = 0.4;
SelMuRat = 0.1;
roted = 0;
for i=1:2
    if i==2
    demantion = 100;
    end
    mkdir(strcat('comput result/'));
if i~=2 
% % % %  ----------------����---------------------------------------------
% %         PSOLHSimproveZhongMuMinQHMinDmF(@Schwefel,@regress11,@LHspso,30,0.9,0.9,c3,w,2000,demantion,'Schwefel',10,accuracy,SelMuRat,roted);
% %         PSOLHSimproveZhongMuMinQHMinDmF(@DiffPower,@regress11,@LHspso,30,0.9,0.9,c3,w,2000,demantion,'DiffPower',100,accuracy,SelMuRat,roted);
% % % % ------------------���-----------------------------------------------
% %         PSOLHSimproveZhongMuMinQHMinDmF(@AckleyFunction,@regress11,@LHspso,30,0.9,0.9,c3,w,5000,demantion,'AckleyFunction',32,accuracy,SelMuRat,roted);
% %         PSOLHSimproveZhongMuMinQHMinDmF(@Salomon,@regress11,@LHspso,30,0.9,0.9,c3,w,5000,demantion,'Salomon',100,accuracy,SelMuRat,roted);
% %  
% % % -------------------����---------------------------------------------------
% %         PSOLHSimproveZhongMuMinQHMinDmF(@NoisySchwefel,@regress11,@LHspso,30,0.9,0.9,c3,w,2000,demantion,'NoisySchwefel',100,accuracy,SelMuRat,roted);
end
end
end

% function mainPsoLHS
% % demList = [200 500 1000];
% % for dem = 1:3
% % demantion = demList(dem);
% demantion = 30;
% accuracy = 10^(-5);
% c3 = 0.4;
% w = 0.4;
% SelMuRat = 0.1;
% roted = 0;
% %     for SelMuRat = 0.3:0.1:0.7
% %     for w = 0.2:0.2:0.8;
% %     for c3 = 0:0.2:2
% % -----------all the test function ---------------------------------------------------------------------------------------------------------------------------
% % % %  ----------------����---------------------------------------------
% %         PSOLHSimproveZhongMuMinQHMinDmF(@Schwefel,@regress11,@LHspso,30,0.9,0.9,c3,w,2000,demantion,'Schwefel',10,accuracy,SelMuRat,roted);
% %         PSOLHSimproveZhongMuMinQHMinDmF(@DiffPower,@regress11,@LHspso,30,0.9,0.9,c3,w,2000,demantion,'DiffPower',100,accuracy,SelMuRat,roted);
% % % % ------------------���-----------------------------------------------
% %         PSOLHSimproveZhongMuMinQHMinDmF(@AckleyFunction,@regress11,@LHspso,30,0.9,0.9,c3,w,5000,demantion,'AckleyFunction',32,accuracy,SelMuRat,roted);
% %         PSOLHSimproveZhongMuMinQHMinDmF(@Salomon,@regress11,@LHspso,30,0.9,0.9,c3,w,5000,demantion,'Salomon',100,accuracy,SelMuRat,roted);
% %  
% % % -------------------����---------------------------------------------------
% %         PSOLHSimproveZhongMuMinQHMinDmF(@NoisySchwefel,@regress11,@LHspso,30,0.9,0.9,c3,w,2000,demantion,'NoisySchwefel',100,accuracy,SelMuRat,roted);
% 
% %     end
% end
% % end