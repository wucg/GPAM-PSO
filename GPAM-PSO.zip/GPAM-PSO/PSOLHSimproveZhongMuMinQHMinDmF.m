function result = PSOLHSimproveZhongMuMinQHMinDmF(fitness,regress,LHS,N,c1,c2,c3,w,M,D,fileName,boundary,accuracy,SelMuRat,roted)

% Dminima setting parameters vmax = 0.9;c1=c2=c3 = 0.9;w = 0.7
% 100---4000 add minwhere. mutation every dozens iterations
% select mutated dimension PSOLHS2��if mutated failure 10 times, selects the best form mutate 3 times 
% N:amount of paticals��
% M: max_iterations��
% D: dimension of partical��
% Q: running times��
if M <=2000
    firstNumMinwhere = M-1;                                                   % single-modality times inwhere
else
    firstNumMinwhere = 50;                                                      % multimodality
end
eachIntMinwhere = 100;                                                      % when to add minwhere
lastIntMinwhere = 50;                                                       % when to add minwhere from the end
%---------------Init Parameters-----------------
% min_dis = 0.05;
% accuMark = 0;
% for rand11 = 0.01:0.1:1
Q=51;
failSeqNumMax = 5;                          % upper boundary of continuous falsure
failSeqNum = 0;                             % add failure counts of no promotion 
num = 0;                                    % counts of out of boundary
cn1 = 0.2;                                  % when mutation��waken pbest
cn2 = 0.2;                                  % when mutation��waken gbest
% num1 = 0;                                 % counts of mutation��number of mutation particles��
% num11 = 0;                                % improved particles
% num1111 = 0;
numNormRandMin_where = 4;                   %  min_where uniform distribution particals
p=zeros(1,N);                               %  fitness of pbest p(i)
y=zeros(N,D);                               %  pbest position  y(i)
Pbest = zeros(1,M);                         %  all the pbest fitness of each iteration
min_whereFitness = zeros(1,M);
vmax = 0.9;
result.Pbest = [];
result.runtime = [];
result.xm = [];
result.fv = [];
result.accept_iter = [];
result.successEvaluation = [];              %  the counts of particles meet acc_cutoff
result.figPbest = [];                       %  the best Pbest in Q times running pro, plot
result.min_whereFitness = [];
regressX = [];
regressXpca = [];
result.x = [];
result.fitness = [];
result.min_wherewhere = [];
intervalNum = 30;                           % one dimension is divided into 30 intervals
% clusMatrix = zeros(D,intervalNum);
% SelMuRat = 0.3;
% suus = 0;
DemOfMut = 30;
NumOfMut = 30;
rand11 = 0.7;
rand22 = 0.2;
format long;
MM = gallery('randhess',D,'double');

%% Run the algorithm Q times /
disp(fileName);
result.firstNumPbest = [];                                                 % record the pbest after adding minwhere
for runNum = 1:Q
    pcaMatrix = [];
    MuDistance = [];
    wheel = 0;
    accept_iter = 0;                                                       % the iterations achieve best fitness
    sumEvaluation = 0;
    successEvaluation = 0;
    NormRnd = zeros(numNormRandMin_where,D);                               %  min_where position
    
    MutNum_num = ones(1,NumOfMut)*400;                                     
    MutEither = 0;
    
    disp([ num2str(runNum) '=====================']);
    %% -----------random creat,based on the clock------------------
    stream = RandStream('mt19937ar', 'Seed', sum(100 * clock));
    RandStream.setGlobalStream(stream);
    tic;                                                                   % tic timing
    
    %% init population position and velocity 
    %v = rand(N,D) * (2*boundary) - boundary;
    v = rand(N,D);
    x = LHS(boundary,N,D);
    % x = (2*boundary)*rand(N,D)-boundary;
    
    %% init gbest and pbest
    for i=1:N
        p(i)=fitness(x(i,:),D,roted,MM);                                    % p(i) fitness
        y(i,:)=x(i,:);                                                      % y(i) position
    end
    pg = x(N,:);
    for i=1:(N-1)
        if fitness(x(i,:),D,roted,MM)<fitness(pg,D,roted,MM)
            pg=x(i,:);                                                      % Pg gbest position
        end
    end
    min_where = rand(1,D)*(2*boundary) - boundary;                          % init min_where
    
    %% start iteration
    for interNum=1:M
        %clusMatrix = zeros(D,intervalNum);
        % SelDem = [];                                                       % mutation dimension
        % =============================update N particals================================= ;
        for MarkOfPar=1:N
            if interNum >firstNumMinwhere && interNum<M-lastIntMinwhere
                if mod(interNum,eachIntMinwhere) == 0
                    v(MarkOfPar,:)=w*v(MarkOfPar,:)+c1*rand*(y(MarkOfPar,:)-x(MarkOfPar,:))...
                        +c2*rand*(pg-x(MarkOfPar,:))+c3*rand*(min_where-x(MarkOfPar,:));
                    x(MarkOfPar,:)=x(MarkOfPar,:)+v(MarkOfPar,:);
                else
                    if MutEither == 1 &&  ~all( MutNum_num-MarkOfPar)
                        %     disp(['&&&&&&&&&&&&' num2str(MarkOfPar)])
                        v(MarkOfPar,:)=w*v(MarkOfPar,:)+cn1*rand*(y(MarkOfPar,:)...
                            -x(MarkOfPar,:))+cn2*rand*(pg-x(MarkOfPar,:));
                        x(MarkOfPar,:)=x(MarkOfPar,:)+v(MarkOfPar,:);
                    else
                        v(MarkOfPar,:)=w*v(MarkOfPar,:)+c1*rand*(y(MarkOfPar,:)...
                            -x(MarkOfPar,:))+c2*rand*(pg-x(MarkOfPar,:));
                        x(MarkOfPar,:)=x(MarkOfPar,:)+v(MarkOfPar,:);
                        
                    end
                    % if abs(interNum-100*(ceil(interNum/100)))<5
                    % disp(['Iteration:' num2str(interNum) '; ' 'The Partical: ' num2str(MarkOfPar) ':'])%
                    % disp('velocity' )
                    % v(MarkOfPar,:)
                    % disp('position')
                    % x(MarkOfPar,:)%
                    % end
                end
            elseif  interNum<=firstNumMinwhere
                v(MarkOfPar,:)=w*v(MarkOfPar,:)+c1*rand*(y(MarkOfPar,:)-x(MarkOfPar,:))...
                    +c2*rand*(pg-x(MarkOfPar,:))+c3*rand*(min_where-x(MarkOfPar,:));
                x(MarkOfPar,:)=x(MarkOfPar,:)+v(MarkOfPar,:);
                % elseif interNum>=4000
                % v(MarkOfPar,:)=w*v(MarkOfPar,:)+c2*rand*(pg-x(MarkOfPar,:))+c3*rand*(min_where-x(MarkOfPar,:));
                % x(MarkOfPar,:)=x(MarkOfPar,:)+v(MarkOfPar,:);
            elseif interNum>=M-lastIntMinwhere
                if fitness(min_where,D,roted,MM)<fitness(pg,D,roted,MM)
                    v(MarkOfPar,:)=w*v(MarkOfPar,:)+c1*rand*(y(MarkOfPar,:)-x(MarkOfPar,:))...
                        +c3*rand*(min_where-x(MarkOfPar,:));
                    x(MarkOfPar,:)=x(MarkOfPar,:)+v(MarkOfPar,:);
                else
                    v(MarkOfPar,:)=w*v(MarkOfPar,:)+c1*rand*(y(MarkOfPar,:)-x(MarkOfPar,:))...
                        +c2*rand*(pg-x(MarkOfPar,:));
                    x(MarkOfPar,:)=x(MarkOfPar,:)+v(MarkOfPar,:);
                end
            end
            
            %% ----------------------------boundary judgement-----------------------------------
            for k=1:D
                if x(MarkOfPar,k)<-boundary;
                    x(MarkOfPar,k)=-boundary*rand;
                    % if interNum>50
                    % disp(['Partical:' num2str(MarkOfPar) '; Dimension: ' num2str(k)])
                    % disp('==========')
                    % disp(interNum);
                    % end
                    %                     num = num +1;
                elseif x(MarkOfPar,k)>boundary
                    x(MarkOfPar,k)=rand*boundary;
                    num = num +1;
                end
            end
            
            %------------------------------velocity judgement----------------------------------
            for k = 1:D
                if v(MarkOfPar,k)>vmax
                    % num = num +1;
                    v(MarkOfPar,k)=rand*vmax;
                elseif v(MarkOfPar,k)<-vmax
                    % num = num +1;
                    v(MarkOfPar,k)=-vmax*rand;
                end
            end

            %---------------------------update pbest y(i)------------------------------
            
            sumEvaluation = sumEvaluation +1;
            
            if fitness(x(MarkOfPar,:),D,roted,MM)<p(MarkOfPar)
                
                p(MarkOfPar)=fitness(x(MarkOfPar,:),D,roted,MM);            
                
                y(MarkOfPar,:)=x(MarkOfPar,:);                              
                
            end
            %----------------------------The 1st time achieve the best------------------------------------
            if wheel == 0
                if p(MarkOfPar)<accuracy
                    % disp(['Iteration',num2str(runNum),'��',num2str(toc)]);% running time
                    successEvaluation = sumEvaluation;
                    accept_iter = interNum;
                    endtime = toc;
                    % disp(successEvaluation);
                    % disp('success!');
                    wheel = 1;
                    % return;
                end
            end
        end
        
        %==================update gbest�� Pbest======================
        for i = 1:N
            if p(i)<fitness(pg,D,roted,MM)
                pg=y(i,:);
            end
            Pbest(interNum)=fitness(pg,D,roted,MM);
        end
        %disp(['interNum' num2str(interNum) 'Pbest(interNum)' num2str(Pbest(interNum))]);
        
        
        %% ===============================Mutation===========================-lastIntMinwhere
        sumSwarmFit = 0;
        for parrr = 1:N
            sumSwarmFit = sumSwarmFit + fitness(x(parrr,:),D,roted,MM);
        end
        meanSwarmFit = sumSwarmFit/N;
        
        if interNum>1 && interNum>firstNumMinwhere && interNum<M-lastIntMinwhere && abs(Pbest(interNum)-Pbest(interNum-1))<meanSwarmFit/50
            failSeqNum = failSeqNum+1;
        else
            failSeqNum = 0;
        end
        
        if failSeqNum>=failSeqNumMax
            % find the mutation particle and dimension
            [MutNum_num,MutDe_num] = MutProMulDem(x,SelMuRat,N,D,NumOfMut,DemOfMut,interNum);
            %% multi-dimension mutation in one particle
            for MuNum = 1:NumOfMut
                xMut=[ x(MutNum_num(MuNum),:); x(MutNum_num(MuNum),:); x(MutNum_num(MuNum),:)];
                for accuNum = 1:3
                    if rand >rand11
                        if rand >0.5
                            arand = (xMut(accuNum,MutDe_num(MuNum,:)) +boundary)*(1- 0.2.^((1-interNum/M).^1));
                            xMut(accuNum,MutDe_num(MuNum,:)) = xMut(accuNum,MutDe_num(MuNum,:)) - arand;
                            MuDistance = [MuDistance arand];
                        else
                            arand =(boundary-xMut(accuNum,MutDe_num(MuNum,:)))*( 1-0.2.^((1-interNum/M).^1));
                            xMut(accuNum,MutDe_num(MuNum,:)) = xMut(accuNum,MutDe_num(MuNum,:)) + arand;
                            MuDistance = [MuDistance arand];
                        end
                    else
                        if rand >0.5
                            arand = (xMut(accuNum,MutDe_num(MuNum,:)) +boundary)*( 0.2.^((1-interNum/M).^1)-0.1);
                            xMut(accuNum,MutDe_num(MuNum,:)) = xMut(accuNum,MutDe_num(MuNum,:)) - arand;
                            MuDistance = [MuDistance arand];
                        else
                            arand =(boundary-xMut(accuNum,MutDe_num(MuNum,:)))*( 0.2.^((1-interNum/M).^1)-0.1);
                            xMut(accuNum,MutDe_num(MuNum,:)) = xMut(accuNum,MutDe_num(MuNum,:)) + arand;
                            MuDistance = [MuDistance arand];
                        end
                    end
                end
                besXmut = xMut(1,:);
                for AccuNum = 2:3
                    if fitness(xMut(AccuNum,:),D,roted,MM)<fitness(besXmut,D,roted,MM)
                        besXmut = xMut(AccuNum,:);
                    end
                end
                if rand >rand22
                    x(MutNum_num(MuNum),:) = besXmut;
                    sumEvaluation = sumEvaluation +1;
                end
            end
            failSeqNum = 0;
            MutEither = 1;
        else
            MutEither = 0;
        end
        
        %% minwhere--interNum>=M-lastIntMinwhere
        if interNum <firstNumMinwhere || interNum+1>=M-lastIntMinwhere|| mod(interNum+1,eachIntMinwhere)==0
            interNum
            %---------------regress to update min_where------------------------
            X = zeros(N,D);
            Y = zeros(N,1);
            for k = 1:N;
                X(k,:) = x(k,:);
                Y(k,:)= fitness(x(k,:),D,roted,MM);
            end
            [ min_where pcamatrix]= regress(X,Y,boundary,D,regressX,regressXpca,interNum,N);
            pcaMatrix= [pcaMatrix pcamatrix];
            min_wherewhere(interNum,:) = min_where;
            % --------------------update MSE ------------------------------
            for i = 1:D
                estMatr = abs(x(:,i)-min_where(i));
                MinID = 1;
                MinDis = estMatr(1);
                % MinID = find(estMatr==min(estMatr));
                % -----------------find the nearest partical----------------------
                for j = 2:N
                    if estMatr(j)<MinDis
                        MinID = j;
                        MinDis = estMatr(MinID);
                    end
                end
                % --4 points in one dimension Expection-min_where near the middle point��variance nearest distance
                NormRnd(1:numNormRandMin_where,i) = normrnd...
                    ((min_where(i)+x(MinID,i))/2, MinDis,numNormRandMin_where,1);
            end
            min_whereFitness(interNum) = fitness(min_where,D,roted,MM);
            
            for  q = 1: numNormRandMin_where
                
                MinNeib = fitness(NormRnd(q,:),D,roted,MM);
                
                if  MinNeib < min_whereFitness(interNum)
                    
                    min_whereFitness(interNum) = MinNeib;
                    
                    min_where =  NormRnd(q,:);
                    
                end
                
            end
            %sumEvaluation = sumEvaluation +5;
        end
        
    end
    
    %% ===============iteration stop output
    disp('success===========');
    %--------------------------running time------------------------
    if wheel == 0
        endtime = toc;
    end
    fitness(pg,D,roted,MM)
    accept_iter
    endtime
    result.runtime = [result.runtime endtime];
    result.x = x;
    result.xm = [result.xm  pg'];
    result.fv = [result.fv fitness(pg,D,roted,MM)];
    result.Pbest = [result.Pbest Pbest'];
    result.accept_iter = [result.accept_iter accept_iter];
    result.successEvaluation = [result.successEvaluation successEvaluation];
    result.firstNumPbest = [result.firstNumPbest Pbest(firstNumMinwhere+1)];
    result.vlast =  v;
    result.pcaMatrix = pcaMatrix;
    result.min_whereFitness = [result.min_whereFitness min_whereFitness'];
    %result.min_wherewhere = min_wherewhere;
    for par = 1:N
        fitnesss(par) = fitness(x(par,:),D,roted,MM) ;
    end
    result.fitness = fitnesss;
end
% save(['ceshiceshiGPAM-PSO'],'result');
%----------------------the best Pbest from Q times, as figPbest--------------
minIte = 1;
for i = 2:Q
    if result.fv(i)<result.fv(minIte)
        minIte = i;
    end
end
result.figPbest = result.Pbest(:,minIte);
save(['comput result/' fileName 'dimension' num2str(D) 'GPAM-PSO'],'result');

