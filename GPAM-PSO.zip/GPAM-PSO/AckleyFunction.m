function F = AckleyFunction(x,demantion,roted,M)
% AckleyFunction  boundary=32

if roted==1
    x = x*M';
end

total = 0;

totalcos = 0;
for i = 1:demantion
    
    total = total+x(i)^2;
    
    totalcos = totalcos+cos(2*pi*x(i));
    
end
% total
% totalcos

F1 = -20*exp(-0.2*sqrt(total/demantion));
F2 =  -exp(totalcos/demantion)+20+exp(1);
F = F1+F2;