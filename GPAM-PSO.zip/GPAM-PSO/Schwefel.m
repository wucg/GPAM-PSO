function F = Schwefel(x,demantion,~,~)
% Schwefel  boundary=10

total = 0;
total2 = 1;
for i = 1:demantion
    total = total+abs(x(i));

    total2 = total2*abs(x(i));
end
F = total+total2;