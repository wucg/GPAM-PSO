function F = NoisySchwefel(x,demantion,roted,M)
if roted==1
    x = x*M';
end

total = 0;
for i = 1:demantion
    total2 = 0;
    for j = 1:i
     total2 = total2+x(j);   
    end
    total = total+total2^2;

end
F = total*(1+0.4*abs(normrnd(0,1)));