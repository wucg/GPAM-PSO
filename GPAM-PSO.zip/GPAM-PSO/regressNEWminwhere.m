function Xprof = regressNEWminwhere(X,Y,boundary,demantion)

% [COEFF ,latent,explained] = pcacov( cov(X));
%  diag(cov(X));
%  s = svd(diag(cov(X)));
%% pca get the coeff
COEFF = pcacov(cov(X));

COEFFpca = COEFF(1:demantion,1:2);
%% get the regress data Xpca ,Y to cmplete the regress,coeff is B
Xpca = X*COEFFpca ;

one=ones(length(Y),1);

x1 = Xpca(:,1);
x2 = Xpca(:,2);

X1=[x1,x2,one];

X2=[x1.*x1,x1.*x2,x2.*x2,X1];

B = regress(Y,X2);

a1 = B(1,1);
a2 = B(2,1);
a3 = B(3,1);
a4 = B(4,1);
a5 = B(5,1);
a6 = B(6,1);
%% get the min_where Xprof
A = [2*a1 a2
     a2  2*a3];

L = [-a4
    -a5];

if rank(A) == 2
    
    Xpro = A\L;
    
else
        
    Xpro = pinv(A)*L;
    
end

Xprof = zeros(1,demantion);

Xprof(1) = Xpro(1);

Xprof(2) = Xpro(2);

Xprof = Xprof* pinv(COEFF);
%%   test the boundary
for i = 1:demantion
    if Xprof(i)>boundary 
        Xprof(i) = rand*boundary;
    elseif Xprof(i)<-boundary
            Xprof(i)=-rand*boundary;       
    end
end
        
        
                 









